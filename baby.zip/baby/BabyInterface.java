
//Interface
public interface BabyInterface {

    //Two abstract methods
    public String BabySound();

    public String BabySound(String message);

    @Override
    public String toString();
}
